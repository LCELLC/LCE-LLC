# LCE LLC — Portfolio & Asset Management

## 🚀 Mettre en ligne en 5 minutes (gratuit)

### Étape 1 : Créer un compte GitHub
1. Allez sur **https://github.com** → cliquez "Sign up"
2. Créez votre compte (gratuit)

### Étape 2 : Créer un nouveau dépôt (repository)
1. Une fois connecté, cliquez le **+** en haut à droite → **"New repository"**
2. Nom : `lce-llc` (ou ce que vous voulez)
3. Cochez **"Public"**
4. Cliquez **"Create repository"**

### Étape 3 : Uploader les fichiers
1. Sur la page du repository, cliquez **"uploading an existing file"**
2. Glissez-déposez TOUS les fichiers et dossiers de ce projet :
   - `package.json`
   - `vite.config.js`
   - `index.html`
   - Le dossier `src/` (avec `main.jsx` et `App.jsx`)
3. Cliquez **"Commit changes"**

### Étape 4 : Déployer sur Vercel (gratuit)
1. Allez sur **https://vercel.com** → cliquez "Sign Up"
2. Choisissez **"Continue with GitHub"**
3. Autorisez Vercel à accéder à votre GitHub
4. Cliquez **"Import Project"** (ou "Add New" → "Project")
5. Sélectionnez votre repository `lce-llc`
6. Vercel détecte automatiquement que c'est un projet Vite
7. Cliquez **"Deploy"**
8. ✅ Attendez ~1 minute, votre site est en ligne !

### Votre URL
Vercel vous donnera une URL gratuite du type :
**https://lce-llc.vercel.app**

Vous pouvez partager ce lien directement sur LinkedIn et WhatsApp !

---

## 🔐 Accès Administrateur

Le code PIN par défaut est : **2024**

Pour le changer :
1. Ouvrez le fichier `src/App.jsx`
2. Trouvez la ligne : `const ADMIN_PIN = "2024";`
3. Remplacez "2024" par votre code secret
4. Enregistrez et faites un commit sur GitHub
5. Vercel redéploie automatiquement

### Mode Admin
- Cliquez sur **"Admin"** en haut à droite du site
- Entrez votre PIN
- Vous pouvez maintenant ajouter, modifier et supprimer des actifs
- Les visiteurs voient les actifs mais NE PEUVENT PAS les modifier

---

## 🌐 Nom de domaine personnalisé (optionnel)

Si plus tard vous achetez un domaine (ex: lcellc.com) :
1. Achetez-le sur **Namecheap** ou **Google Domains** (~12$/an)
2. Dans Vercel → Settings → Domains → ajoutez votre domaine
3. Suivez les instructions DNS de Vercel

---

## 📱 Partager sur LinkedIn & WhatsApp

### LinkedIn
- Allez sur votre profil LinkedIn
- Section "Coordonnées" → ajoutez votre URL comme site web
- Ou postez simplement le lien dans un post

### WhatsApp
- Copiez votre URL Vercel
- Mettez-le dans votre statut WhatsApp Business
- Ou envoyez-le directement à vos contacts

---

## 📧 Contact configuré
- Email : Infos.LCE@proton.me
- Téléphone : +1 (954) 795-0682
- WhatsApp : wa.me/19547950682
- Localisations : Miami, FL · Genève, CH
